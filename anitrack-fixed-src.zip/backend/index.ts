import { router, json, error, db, auth, ai } from '@appdeploy/sdk';

type Anime = {
  malId: number;
  title: string;
  titleJapanese?: string;
  image?: string;
  synopsis?: string;
  episodes?: number | null;
  status?: string;
  year?: number | null;
  seasonCount?: number;
  airedFrom?: string | null;
  airedTo?: string | null;
  // Catalog facts straight from MAL/Jikan (never AI-generated)
  type?: string;
  // Deterministic category derived from MAL `type`
  kind?: Kind;
  // Release-order index among TV entries of a franchise (null for non-TV)
  seasonNumber?: number | null;
  franchiseId?: string;
  franchiseTitle?: string;
  refreshedAt?: string;
};
type Kind = 'tv_season' | 'movie' | 'ova' | 'special' | 'crossover';
type Entry = {
  id: string;
  userId: string;
  anime: Anime;
  watchedSeasons: number[];
  watchedEpisodes: Record<string, number[]>;
  addedAt: string;
};
const KINDS: Kind[] = ['tv_season', 'movie', 'ova', 'special', 'crossover'];
// Deterministic category from MAL's own `type` field. AI is never used for this.
function kindFromType(t: any): Kind | undefined {
  const v = String(t || '').toLowerCase();
  if (v === 'tv') return 'tv_season';
  if (v === 'movie') return 'movie';
  if (v === 'ova' || v === 'ona') return 'ova';
  if (v === 'special' || v === 'tv special') return 'special';
  return undefined;
}
// CM / PV / Music entries are promo clips, not watchable franchise entries.
const SKIP_TYPES = new Set(['cm', 'pv', 'music']);
const sleep = (ms: number) => new Promise(r => setTimeout(r, ms));
const safeKey = (id: string) =>
  'u' +
  Array.from(id)
    .map(c => c.charCodeAt(0).toString(16))
    .join('')
    .slice(0, 110);
const tableFor = (userId: string) => 'watch_' + safeKey(userId);
const animeFrom = (a: any): Anime => ({
  malId: Number(a.malId),
  title: String(a.title || '').slice(0, 250),
  titleJapanese: a.titleJapanese
    ? String(a.titleJapanese).slice(0, 250)
    : undefined,
  image: a.image ? String(a.image).slice(0, 1000) : undefined,
  synopsis: a.synopsis ? String(a.synopsis).slice(0, 2000) : undefined,
  episodes:
    a.episodes == null
      ? null
      : Math.max(1, Math.min(1000, Number(a.episodes) || 1)),
  status: a.status ? String(a.status).slice(0, 100) : undefined,
  year: a.year == null ? null : Number(a.year) || null,
  // Season count is not a catalog fact for a single MAL entry. Keep legacy values only when already stored.
  seasonCount: Number.isInteger(a.seasonCount) && a.seasonCount > 0 ? Math.min(8, Number(a.seasonCount)) : undefined,
  airedFrom: a.airedFrom || null,
  airedTo: a.airedTo || null,
  type: a.type ? String(a.type).slice(0, 40) : undefined,
  kind: kindFromType(a.type) ?? (KINDS.includes(a.kind) ? a.kind : undefined),
  seasonNumber: Number.isInteger(a.seasonNumber) && a.seasonNumber > 0 ? a.seasonNumber : null,
  franchiseId: a.franchiseId ? String(a.franchiseId).slice(0, 60) : undefined,
  franchiseTitle: a.franchiseTitle ? String(a.franchiseTitle).slice(0, 250) : undefined,
  refreshedAt: a.refreshedAt ? String(a.refreshedAt) : undefined,
});
async function currentUser(event: any) {
  return auth.getUser(event);
}
async function fetchAnime(url: string, attempt = 0): Promise<any> {
  const res = await fetch(url, { headers: { Accept: 'application/json' } });
  if ((res.status === 429 || res.status >= 500) && attempt < 3) {
    const retryAfter = Number(res.headers.get('retry-after')) || 0;
    await sleep(Math.max(retryAfter * 1000, 800 * 2 ** attempt));
    return fetchAnime(url, attempt + 1);
  }
  if (!res.ok) throw new Error('Anime catalog returned ' + res.status);
  return res.json();
}
function mapAnime(item: any): Anime {
  const a = item?.node || item;
  const malId = Number(a?.mal_id || a?.id);
  const title = String(a?.title || 'Unknown anime');
  const eps = a?.episodes == null ? null : Number(a.episodes);
  return {
    malId,
    title,
    titleJapanese: a?.title_japanese || undefined,
    image:
      a?.images?.jpg?.large_image_url ||
      a?.images?.jpg?.image_url ||
      a?.main_picture?.large ||
      a?.main_picture?.medium ||
      undefined,
    synopsis: a?.synopsis || undefined,
    episodes: eps,
    status: a?.status || undefined,
    year: a?.year || a?.aired?.prop?.from?.year || null,
    // Never infer season count from episode count; MAL/Jikan supplies entry-level facts only.
    seasonCount: undefined,
    airedFrom: a?.aired?.from || null,
    airedTo: a?.aired?.to || null,
    type: a?.type || undefined,
    kind: kindFromType(a?.type),
    seasonNumber: null,
    refreshedAt: new Date().toISOString(),
  };
}
export const refreshCatalogHandler = async (_event: {
  type: 'cron';
  name: string;
}) => {
  try {
    const data = await fetchAnime(
      'https://api.tenrai.org/v1/seasons/now?sfw=true'
    );
    const items = (data.data || []).slice(0, 100).map(mapAnime);
    const id = 'current';
    const existing = await db.get<any>('catalog_cache', [id]);
    const record = {
      items,
      updatedAt: new Date().toISOString(),
      source: 'MyAnimeList catalog via Tenrai',
      kind: 'current-season',
    };
    if (existing[0]) await db.update('catalog_cache', [{ id, record }]);
    else await db.add('catalog_cache', [{ ...record, id }]);
  } catch (e) {
    console.error('Catalog refresh failed', e);
  }
  return { statusCode: 200 };
};
const API = 'https://api.tenrai.org/v1';
const FIVE_MIN = 5 * 60 * 1000;
// Relations that belong to the same franchise. "Other" and "Character" are excluded on
// purpose: MAL uses them for crossovers and cameos, which would merge unrelated franchises.
const FRANCHISE_RELATIONS = new Set([
  'prequel', 'sequel', 'parent story', 'side story', 'summary',
  'full story', 'alternative version', 'alternative setting', 'spin-off',
]);
const MAX_NODES = 40;

async function listAll(table: string): Promise<Entry[]> {
  const out: Entry[] = [];
  const seen = new Set<string>();
  let cursor: any = undefined;
  for (let i = 0; i < 20; i++) {
    const page: any = await db.list<Entry>(table, cursor ? { limit: 100, cursor } : { limit: 100 });
    let fresh = 0;
    for (const item of page.items || []) {
      if (!seen.has(item.id)) { seen.add(item.id); out.push(item); fresh++; }
    }
    cursor = page.nextCursor ?? page.cursor ?? page.next_cursor;
    if (!cursor || fresh === 0) break;
  }
  return out;
}
const summarize = (entries: Entry[]) => ({
  entries: entries.length,
  watchedEpisodes: entries.reduce(
    (n, e) => n + Object.values(e.watchedEpisodes || {}).reduce((x, a) => x + a.length, 0), 0),
  watchedSeasons: entries.reduce((n, e) => n + (e.watchedSeasons || []).length, 0),
});
const lastRefreshed = (entries: Entry[]) =>
  entries.map(e => e.anime?.refreshedAt).filter(Boolean).sort().pop() || null;

type Node = { id: string; anime: Anime; related: number[]; fetchedAt: string };
// One cached catalog record per MAL entry (metadata + franchise-relevant relations).
async function getNode(malId: number): Promise<Node | null> {
  const cacheId = 'mal' + malId;
  const [cached] = await db.get<any>('anime_cache', [cacheId]);
  if (cached && Date.now() - Date.parse(cached.fetchedAt) < 24 * 3600 * 1000) return cached as Node;
  const data = await fetchAnime(API + '/anime/' + malId + '/full');
  const a = data?.data;
  if (!a) return null;
  let rels = a.relations;
  if (!Array.isArray(rels)) {
    const r = await fetchAnime(API + '/anime/' + malId + '/relations');
    rels = r?.data || [];
  }
  const related: number[] = [];
  for (const r of rels)
    if (FRANCHISE_RELATIONS.has(String(r?.relation || '').toLowerCase()))
      for (const e of r.entry || [])
        if (e?.type === 'anime' && e?.mal_id) related.push(Number(e.mal_id));
  const node: Node = { id: cacheId, anime: mapAnime(a), related: [...new Set(related)], fetchedAt: new Date().toISOString() };
  try {
    if (cached) await db.update('anime_cache', [{ id: cacheId, record: node }]);
    else await db.add('anime_cache', [node]);
  } catch (e) { console.warn('anime_cache write failed', e); }
  await sleep(350); // stay under the public catalog rate limit
  return node;
}

type Franchise = { id: string; title: string; entries: Anime[]; complete: boolean; pending: number };
// Walks MAL relations from a seed. Time and size bounded; cached nodes make repeat calls cheap,
// so an incomplete result is finished by simply calling again.
async function resolveFranchise(seed: number, deadline: number): Promise<Franchise> {
  const nodes = new Map<number, Node>();
  const visited = new Set<number>([seed]);
  const queue: number[] = [seed];
  let complete = true;
  while (queue.length) {
    if (nodes.size >= MAX_NODES || Date.now() > deadline) { complete = false; break; }
    const id = queue.shift()!;
    try {
      const node = await getNode(id);
      if (!node) { complete = false; continue; }
      nodes.set(id, node);
      for (const r of node.related) if (!visited.has(r)) { visited.add(r); queue.push(r); }
    } catch (e) {
      console.warn('Franchise node failed', id, e);
      complete = false;
    }
  }
  const all = [...nodes.values()].map(n => n.anime)
    .filter(a => !SKIP_TYPES.has(String(a.type || '').toLowerCase()));
  const byDate = (a: Anime, b: Anime) =>
    (Date.parse(a.airedFrom || '') || Infinity) - (Date.parse(b.airedFrom || '') || Infinity) || a.malId - b.malId;
  all.sort(byDate);
  const id = 'f' + Math.min(...[...nodes.keys(), seed]);
  const firstTv = all.find(a => a.kind === 'tv_season') || all[0];
  const title = firstTv?.title || 'Anime';
  let tv = 0;
  const entries = all.map(a => ({
    ...a,
    kind: a.kind || ('special' as Kind),
    seasonNumber: a.kind === 'tv_season' ? ++tv : null,
    franchiseId: id,
    franchiseTitle: title,
  }));
  return { id, title, entries, complete, pending: queue.length };
}

// Deletes a record and confirms by reading it back. The delete call's return shape is not
// relied on: a successful delete must never be reported as an error.
async function removeRecord(table: string, id: string): Promise<'deleted' | 'missing'> {
  const [saved] = await db.get<Entry>(table, [id]);
  if (!saved) return 'missing';
  await db.delete(table, [id]);
  const [still] = await db.get<Entry>(table, [id], { consistent: true });
  if (still) throw new Error('Database still contains ' + id + ' after delete');
  return 'deleted';
}

function sanitizeGroups(proposed: any, results: Anime[]) {
  const valid = new Map(results.map(a => [a.malId, a]));
  const used = new Set<number>();
  const groups: Array<{ franchise: string; entries: Array<{ malId: number; kind: string; seasonNumber: number | null }> }> = [];
  for (const g of Array.isArray(proposed) ? proposed : []) {
    const entries: Array<{ malId: number; kind: string; seasonNumber: number | null }> = [];
    for (const e of Array.isArray(g?.entries) ? g.entries : []) {
      const id = Number(e?.malId);
      const a = valid.get(id);
      if (!a || used.has(id)) continue; // unknown or duplicate IDs are dropped
      used.add(id);
      entries.push({ malId: id, kind: kindFromType(a.type) || 'special', seasonNumber: null });
    }
    if (entries.length) groups.push({ franchise: String(g?.franchise || '').slice(0, 250), entries });
  }
  return groups; // anything the AI left out falls back to title grouping on the client
}

export const handler = router({
  'GET /api/me': [
    async ({ event }) => {
      const user = await currentUser(event);
      if (!user) return error('Sign in required', 401);
      return json({ user: { userId: user.userId, name: user.name || 'Anime fan' } });
    },
  ],
  'GET /api/watchlist': [
    async ({ event }) => {
      const user = await currentUser(event);
      if (!user) return error('Sign in required', 401);
      const items = await listAll(tableFor(user.userId));
      return json({
        entries: items.map(({ id, ...x }) => ({ ...x, id })),
        updatedAt: new Date().toISOString(),
        lastRefreshedAt: lastRefreshed(items),
      });
    },
  ],
  'POST /api/watchlist': [
    async ({ event, body }) => {
      const user = await currentUser(event);
      if (!user) return error('Sign in required', 401);
      const data = body as { anime?: Anime };
      if (!data?.anime?.malId || !data?.anime?.title) return error('Valid anime required', 400);
      const anime = animeFrom(data.anime);
      const table = tableFor(user.userId);
      const existing = await listAll(table);
      if (existing.some(x => x.anime?.malId === anime.malId)) return error('Anime already exists', 409);
      const id = 'mal' + anime.malId;
      const entry: Entry = { id, userId: user.userId, anime, watchedSeasons: [], watchedEpisodes: {}, addedAt: new Date().toISOString() };
      const [created] = await db.add(table, [{ ...entry, id }]);
      if (!created) return error('Could not save anime', 500);
      return json({ entry: { ...entry, id: created } }, 201);
    },
  ],
  // Adds a whole franchise: resolves every season/movie/OVA/special from MAL relations,
  // adds the missing ones, and tags already-saved ones without touching their progress.
  'POST /api/franchise/add': [
    async ({ event, body }) => {
      const user = await currentUser(event);
      if (!user) return error('Sign in required', 401);
      const seeds = [...new Set(((body as any)?.seeds || [(body as any)?.malId]).map(Number).filter((n: number) => Number.isInteger(n) && n > 0))].slice(0, 10) as number[];
      if (!seeds.length) return error('malId required', 400);
      const table = tableFor(user.userId);
      const existing = await listAll(table);
      const byMal = new Map(existing.map(e => [e.anime.malId, e]));
      const deadline = Date.now() + 20000;
      const covered = new Set<number>();
      const toAdd: Entry[] = [];
      let tagged = 0;
      let complete = true;
      let title = '';
      for (const seed of seeds) {
        if (covered.has(seed)) continue;
        const f = await resolveFranchise(seed, deadline);
        title = title || f.title;
        complete = complete && f.complete;
        for (const a of f.entries) {
          covered.add(a.malId);
          const have = byMal.get(a.malId);
          if (have) {
            const next = { ...have, anime: { ...have.anime, type: a.type, kind: a.kind, seasonNumber: a.seasonNumber, franchiseId: a.franchiseId, franchiseTitle: a.franchiseTitle } };
            const [ok] = await db.update(table, [{ id: have.id, record: next }]);
            if (ok) tagged++;
          } else if (!toAdd.some(x => x.anime.malId === a.malId)) {
            toAdd.push({ id: 'mal' + a.malId, userId: user.userId, anime: animeFrom(a), watchedSeasons: [], watchedEpisodes: {}, addedAt: new Date().toISOString() });
          }
        }
      }
      if (toAdd.length) {
        const ids = await db.add(table, toAdd.map(e => ({ ...e, id: e.id })));
        if (!ids || !ids.length) return error('Could not save franchise', 500);
      }
      return json({ added: toAdd, tagged, complete, title }, 201);
    },
  ],
  'PUT /api/watchlist/:id': [
    async ({ event, params, body }) => {
      const user = await currentUser(event);
      if (!user) return error('Sign in required', 401);
      const table = tableFor(user.userId);
      const [saved] = await db.get<Entry>(table, [params.id]);
      if (!saved) return error('Anime not found', 404);
      const b = body as { watchedSeasons?: number[]; watchedEpisodes?: Record<string, number[]> };
      const seasons = Array.isArray(b?.watchedSeasons)
        ? [...new Set(b.watchedSeasons.map(Number).filter(n => Number.isInteger(n) && n >= 1 && n <= 8))]
        : saved.watchedSeasons;
      const episodes: Record<string, number[]> = {};
      for (const [s, eps] of Object.entries(b?.watchedEpisodes || {})) {
        const season = Number(s);
        if (season >= 1 && season <= 8 && Array.isArray(eps))
          episodes[String(season)] = [...new Set(eps.map(Number).filter(n => Number.isInteger(n) && n >= 1 && n <= 1000))].slice(0, 1000);
      }
      const next = { ...saved, watchedSeasons: seasons, watchedEpisodes: episodes };
      const [ok] = await db.update(table, [{ id: params.id, record: next }]);
      if (!ok) return error('Could not update progress', 500);
      return json({ entry: next });
    },
  ],
  'DELETE /api/watchlist/:id': [
    async ({ event, params }) => {
      const user = await currentUser(event);
      if (!user) return error('Sign in required', 401);
      try {
        const result = await removeRecord(tableFor(user.userId), String(params.id));
        if (result === 'missing') return error('Anime not found', 404);
        return json({ deleted: true, id: String(params.id) });
      } catch (e) {
        console.error('Watchlist delete failed', params.id, e);
        return error('Could not remove this anime', 500);
      }
    },
  ],
  // Removes several entries at once (whole franchise). Idempotent: missing ids are reported, not fatal.
  'POST /api/watchlist/remove': [
    async ({ event, body }) => {
      const user = await currentUser(event);
      if (!user) return error('Sign in required', 401);
      const ids = Array.isArray((body as any)?.ids) ? [...new Set((body as any).ids.map(String))].slice(0, 100) as string[] : [];
      if (!ids.length) return error('ids required', 400);
      const table = tableFor(user.userId);
      const deleted: string[] = [];
      const missing: string[] = [];
      const failed: string[] = [];
      for (const id of ids) {
        try {
          (await removeRecord(table, id)) === 'deleted' ? deleted.push(id) : missing.push(id);
        } catch (e) { console.error('Bulk delete failed', id, e); failed.push(id); }
      }
      if (failed.length) return json({ deleted, missing, failed }, 500);
      return json({ deleted, missing, failed });
    },
  ],
  // Refreshes catalog metadata for the stalest saved entries (rate limited, small batches).
  // Only `anime` metadata is written; watched progress is never touched.
  'POST /api/watchlist/refresh': [
    async ({ event }) => {
      const user = await currentUser(event);
      if (!user) return error('Sign in required', 401);
      const table = tableFor(user.userId);
      const all = await listAll(table);
      const stale = all
        .filter(e => !e.anime.refreshedAt || Date.now() - Date.parse(e.anime.refreshedAt) > FIVE_MIN)
        .sort((a, b) => (Date.parse(a.anime.refreshedAt || '') || 0) - (Date.parse(b.anime.refreshedAt || '') || 0));
      let refreshed = 0;
      let rateLimited = false;
      for (const e of stale.slice(0, 6)) {
        try {
          const data = await fetchAnime(API + '/anime/' + e.anime.malId);
          if (!data?.data) continue;
          const fresh = mapAnime(data.data);
          const [latest] = await db.get<Entry>(table, [e.id]);
          if (!latest) continue; // deleted meanwhile
          const anime: Anime = { ...latest.anime, title: fresh.title, titleJapanese: fresh.titleJapanese, image: fresh.image || latest.anime.image, synopsis: fresh.synopsis, episodes: fresh.episodes, status: fresh.status, year: fresh.year, airedFrom: fresh.airedFrom, airedTo: fresh.airedTo, type: fresh.type || latest.anime.type, kind: fresh.kind || latest.anime.kind, refreshedAt: new Date().toISOString() };
          const [ok] = await db.update(table, [{ id: e.id, record: { ...latest, anime } }]);
          if (ok) refreshed++;
        } catch (err) {
          console.warn('Refresh failed for', e.id, err);
          rateLimited = true;
          break;
        }
        await sleep(400);
      }
      const after = await listAll(table);
      return json({ refreshed, remaining: Math.max(0, stale.length - refreshed), rateLimited, lastRefreshedAt: lastRefreshed(after) });
    },
  ],
  // One-time (idempotent) consolidation: backs up every record, then tags existing entries with
  // franchise/kind fields. Records and progress are never merged, moved, or deleted.
  'POST /api/watchlist/migrate': [
    async ({ event }) => {
      const user = await currentUser(event);
      if (!user) return error('Sign in required', 401);
      const table = tableFor(user.userId);
      const bak = 'bak_' + table;
      const entries = await listAll(table);
      const before = summarize(entries);
      let backedUp = 0;
      for (let i = 0; i < entries.length; i += 25) {
        const chunk = entries.slice(i, i + 25);
        const have = await db.get<any>(bak, chunk.map(e => 'bk_' + e.id));
        const haveIds = new Set((have || []).filter(Boolean).map((x: any) => x.id));
        const missing = chunk.filter(e => !haveIds.has('bk_' + e.id));
        if (missing.length) {
          await db.add(bak, missing.map(e => ({ id: 'bk_' + e.id, original: e, backedUpAt: new Date().toISOString() })));
          backedUp += missing.length;
        }
      }
      const deadline = Date.now() + 20000;
      const byMal = new Map(entries.map(e => [e.anime.malId, e]));
      const covered = new Set<number>();
      let migrated = 0;
      for (const e of entries) {
        if (e.anime.franchiseId || covered.has(e.anime.malId)) continue;
        if (Date.now() > deadline) break;
        const f = await resolveFranchise(e.anime.malId, deadline);
        for (const a of f.entries) {
          covered.add(a.malId);
          const have = byMal.get(a.malId);
          if (!have || have.anime.franchiseId) continue;
          const next = { ...have, anime: { ...have.anime, type: a.type, kind: a.kind, seasonNumber: a.seasonNumber, franchiseId: a.franchiseId, franchiseTitle: a.franchiseTitle } };
          const [ok] = await db.update(table, [{ id: have.id, record: next }]);
          if (ok) migrated++;
        }
      }
      const afterEntries = await listAll(table);
      const after = summarize(afterEntries);
      return json({
        before, after, backedUp, migrated,
        remaining: afterEntries.filter(e => !e.anime.franchiseId).length,
        progressPreserved: before.entries === after.entries && before.watchedEpisodes === after.watchedEpisodes && before.watchedSeasons === after.watchedSeasons,
      });
    },
  ],
  'GET /api/anime/search': [
    async ({ query }) => {
      const q = (query.q || '').trim();
      if (q.length < 2) return error('Enter at least two characters', 400);
      const cacheId = 's' + safeKey(q.toLowerCase().slice(0, 50));
      try {
        const [hit] = await db.get<any>('search_cache', [cacheId]);
        if (hit && Date.now() - Date.parse(hit.cachedAt) < 30 * 60 * 1000)
          return json({ results: hit.results, groups: hit.groups, source: 'MyAnimeList catalog via Tenrai (cached)', updatedAt: hit.cachedAt });
        const data = await fetchAnime(API + '/anime?q=' + encodeURIComponent(q) + '&limit=10&sfw=true');
        const results: Anime[] = (data.data || []).map(mapAnime).filter((a: Anime) => a.malId && a.title);
        let groups: ReturnType<typeof sanitizeGroups> = [];
        if (results.length > 1) {
          try {
            // AI only decides which results belong to the same franchise. Categories come from MAL `type`.
            const aiResult = await ai.extract({
              prompt: 'Group these MyAnimeList search records by franchise (same story universe). Use only the given malIds; never invent or change IDs; each ID at most once. Return franchise names taken from the titles.',
              content: JSON.stringify(results.map(a => ({ malId: a.malId, title: a.title, year: a.year, type: a.type }))),
              schema: { type: 'object', properties: { groups: { type: 'array', items: { type: 'object', properties: { franchise: { type: 'string' }, entries: { type: 'array', items: { type: 'object', properties: { malId: { type: 'number' } }, required: ['malId'] } } }, required: ['franchise', 'entries'] } } }, required: ['groups'] },
              thinkingMode: 'FAST', maxTokens: 1000,
            });
            groups = sanitizeGroups((aiResult.data as any)?.groups, results);
          } catch (e) { console.warn('AI franchise grouping unavailable; client falls back to title grouping', e); }
        }
        const cachedAt = new Date().toISOString();
        try {
          const rec = { id: cacheId, results, groups, cachedAt };
          const [old] = await db.get<any>('search_cache', [cacheId]);
          if (old) await db.update('search_cache', [{ id: cacheId, record: rec }]);
          else await db.add('search_cache', [rec]);
        } catch (e) { console.warn('search cache write failed', e); }
        return json({ results, groups, source: 'MyAnimeList catalog via Tenrai', updatedAt: cachedAt });
      } catch (e) {
        console.error('Anime search failed', e);
        return error('Anime catalog is temporarily unavailable', 502);
      }
    },
  ],
  'GET /api/catalog/now': [
    async () => {
      const [cached] = await db.get<any>('catalog_cache', ['current']);
      return json({ items: cached?.items || [], updatedAt: cached?.updatedAt || null, source: 'MyAnimeList catalog via Tenrai' });
    },
  ],
});
