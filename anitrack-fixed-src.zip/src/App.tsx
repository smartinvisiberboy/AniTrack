import { Fragment, useEffect, useMemo, useRef, useState } from 'react';
import { auth, api } from '@appdeploy/client';
import {
  Search,
  Plus,
  Check,
  ChevronDown,
  ChevronRight,
  Play,
  Trash2,
  RefreshCw,
  LogOut,
  Clapperboard,
  Sparkles,
  Clock3,
} from 'lucide-react';

type Anime = {
  malId: number;
  title: string;
  titleJapanese?: string;
  image?: string;
  synopsis?: string;
  episodes?: number | null;
  status?: string;
  year?: number | null;
  seasonCount?: number;
  airedFrom?: string | null;
  airedTo?: string | null;
  type?: string;
  kind?: 'tv_season' | 'movie' | 'ova' | 'special' | 'crossover';
  seasonNumber?: number | null;
  franchiseId?: string;
  franchiseTitle?: string;
  refreshedAt?: string;
};
type FranchiseGroup = { franchise: string; entries: Array<{ malId: number; kind: string; seasonNumber: number | null }> };
type Entry = {
  id: string;
  anime: Anime;
  watchedSeasons: number[];
  watchedEpisodes: Record<string, number[]>;
  addedAt: string;
};
const franchiseKey = (title: string) => {
  const t = title.toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
  const rules: Array<[RegExp, string]> = [
    [/kimetsu no yaiba|demon slayer/, 'demon slayer'],
    [/shingeki no kyojin|attack on titan/, 'attack on titan'],
    [/boku no hero academia|my hero academia/, 'my hero academia'],
    [/jujutsu kaisen/, 'jujutsu kaisen'],
    [/re zero|rezero/, 're zero'],
    [/sword art online/, 'sword art online'],
    [/tokyo revengers/, 'tokyo revengers'],
    [/one punch man/, 'one punch man'],
    [/mushoku tensei/, 'mushoku tensei'],
    [/tate no yuusha|rising of the shield hero/, 'rising of the shield hero'],
    [/tensura|that time i got reincarnated as a slime/, 'that time i got reincarnated as a slime'],
  ];
  for (const [pattern, key] of rules) if (pattern.test(t)) return key;
  return t.replace(/\b(season|part|cour|tv|2nd|3rd|4th|second|third|fourth)\b/g, '').replace(/\s+/g, ' ').trim();
};
const franchiseTitle = (key: string, items: Entry[]) => {
  const preferred: Record<string, string> = { 'demon slayer': 'Demon Slayer', 'attack on titan': 'Attack on Titan', 'my hero academia': 'My Hero Academia', 'jujutsu kaisen': 'Jujutsu Kaisen', 're zero': 'Re:Zero', 'sword art online': 'Sword Art Online', 'tokyo revengers': 'Tokyo Revengers', 'one punch man': 'One-Punch Man', 'mushoku tensei': 'Mushoku Tensei', 'rising of the shield hero': 'The Rising of the Shield Hero', 'that time i got reincarnated as a slime': 'That Time I Got Reincarnated as a Slime' };
  return preferred[key] || items[0]?.anime.title || key;
};
const kindOrder: Record<string, number> = { tv_season: 0, movie: 1, ova: 2, special: 3, crossover: 4 };
const kindHeading: Record<string, string> = { tv_season: 'TV series', movie: 'Movies', ova: 'OVAs & ONAs', special: 'Specials', crossover: 'Crossovers' };
const kindBadge = (a: Anime) =>
  a.kind === 'tv_season' ? (a.seasonNumber ? 'TV · #' + a.seasonNumber : 'TV')
  : a.kind === 'movie' ? 'Movie'
  : a.kind === 'ova' ? a.type || 'OVA'
  : a.kind === 'special' ? a.type || 'Special'
  : a.type || '';
// A MAL record is one catalog entry. Do not infer season count from episode totals.
const seasonLabels = (_a: Anime) => 1;
function App() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [entries, setEntries] = useState<Entry[]>([]);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Anime[]>([]);
  const [aiGroups, setAiGroups] = useState<FranchiseGroup[]>([]);
  const [searching, setSearching] = useState(false);
  const [selectedGroup, setSelectedGroup] = useState(0);
  const [open, setOpen] = useState<Record<string, boolean>>({});
  const [adding, setAdding] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [lastRefreshed, setLastRefreshed] = useState<string | null>(null);
  const [refreshNote, setRefreshNote] = useState('');
  const [addNote, setAddNote] = useState('');
  const migratedRef = useRef(false);
  const [tab, setTab] = useState<'all' | 'watching' | 'completed'>('all');
  const [catalogInfo, setCatalogInfo] = useState(
    'MyAnimeList catalog via Jikan'
  );
  useEffect(() => {
    let active = true;
    (async () => {
      try {
        const u = await auth.getUser();
        if (active) setUser(u);
        if (u) {
          const r = await api.get('/api/watchlist');
          if (active) {
            setEntries(r.data.entries || []);
            setLastRefreshed(r.data.lastRefreshedAt || null);
          }
        }
      } catch (e) {
        if (active) setErrorMsg('Could not load your watchlist. Please retry.');
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, []);
  const progress = (e: Entry) => {
    const total = e.anime.episodes;
    if (!Number.isFinite(total) || !total || total < 1) return 0;
    const watched = new Set(Object.values(e.watchedEpisodes || {}).flat()).size;
    return Math.min(100, Math.round((watched / total) * 100));
  };
  const completed = (e: Entry) =>
    progress(e) >= 100 || e.watchedSeasons.length >= seasonLabels(e.anime);
  const filtered = entries.filter(
    e => tab === 'all' || (tab === 'completed' ? completed(e) : !completed(e))
  );
  const groupedFiltered = useMemo(() => {
    const groups = new Map<string, Entry[]>();
    for (const entry of filtered) {
      // Server-resolved franchise id wins; title heuristics only cover not-yet-migrated records.
      const key = entry.anime.franchiseId || 'legacy-' + franchiseKey(entry.anime.title);
      groups.set(key, [...(groups.get(key) || []), entry]);
    }
    return Array.from(groups.entries()).map(([key, items]) => {
      const sorted = [...items].sort(
        (a, b) =>
          (kindOrder[a.anime.kind || 'special'] ?? 9) - (kindOrder[b.anime.kind || 'special'] ?? 9) ||
          (a.anime.seasonNumber ?? 0) - (b.anime.seasonNumber ?? 0) ||
          (Date.parse(a.anime.airedFrom || '') || 0) - (Date.parse(b.anime.airedFrom || '') || 0)
      );
      const known = sorted.reduce((n, e) => n + (e.anime.episodes && e.anime.episodes > 0 ? e.anime.episodes : 0), 0);
      const watched = sorted.reduce(
        (n, e) => n + new Set(Object.values(e.watchedEpisodes || {}).flat()).size, 0);
      return {
        key,
        title: sorted[0].anime.franchiseTitle || franchiseTitle(key.replace('legacy-', ''), sorted),
        entries: sorted,
        known,
        watched,
      };
    });
  }, [filtered]);
  async function reloadList() {
    const r = await api.get('/api/watchlist');
    setEntries(r.data.entries || []);
    setLastRefreshed(r.data.lastRefreshedAt || null);
    return (r.data.entries || []) as Entry[];
  }
  async function runMigration() {
    // Backs up every record server-side, then tags entries with franchise ids. Progress is verified.
    for (let i = 0; i < 6; i++) {
      const r = await api.post('/api/watchlist/migrate', {});
      if (!r.data.progressPreserved) {
        setErrorMsg('Franchise migration stopped: progress totals did not match. A backup of your list was saved.');
        return;
      }
      if (r.data.remaining === 0 || r.data.migrated === 0) break;
    }
    await reloadList();
  }
  async function runRefresh() {
    try {
      for (let i = 0; i < 5; i++) {
        const r = await api.post('/api/watchlist/refresh', {});
        setLastRefreshed(r.data.lastRefreshedAt || null);
        setRefreshNote(r.data.rateLimited ? 'Catalog is rate limiting; will retry shortly.' : '');
        if (r.data.refreshed) await reloadList();
        if (!r.data.remaining || r.data.rateLimited || !r.data.refreshed) break;
      }
    } catch {
      setRefreshNote('Metadata refresh failed; will retry in 5 minutes.');
    }
  }
  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      try {
        if (!migratedRef.current) {
          migratedRef.current = true;
          await runMigration();
        }
      } catch {
        /* migration is retried on next load; data is untouched */
      }
      if (!cancelled) await runRefresh();
    })();
    const timer = setInterval(() => {
      if (document.visibilityState === 'visible') void runRefresh();
    }, 5 * 60 * 1000);
    return () => {
      cancelled = true;
      clearInterval(timer);
    };
  }, [user]);
  async function refreshList() {
    await runRefresh();
    await reloadList();
  }
  const searchSequence = useState({ current: 0 })[0];
  async function searchAnime(e?: React.FormEvent) {
    e?.preventDefault();
    if (!query.trim()) return;
    const sequence = ++searchSequence.current;
    setSearching(true);
    setErrorMsg('');
    try {
      const r = await api.get(
        '/api/anime/search?q=' + encodeURIComponent(query.trim())
      );
      if (sequence !== searchSequence.current) return;
      setResults(r.data.results || []);
      setAiGroups(r.data.groups || []);
      setSelectedGroup(0);
      setCatalogInfo(r.data.source || 'MyAnimeList catalog');
    } catch {
      if (sequence === searchSequence.current) setErrorMsg('Anime search is temporarily unavailable. Please try again.');
    } finally {
      if (sequence === searchSequence.current) setSearching(false);
    }
  }
  useEffect(() => {
    const q = query.trim();
    if (q.length < 2) {
      setResults([]);
      setAiGroups([]);
      setSelectedGroup(0);
      setSearching(false);
      return;
    }
    const timer = setTimeout(() => {
      void searchAnime();
    }, 300);
    return () => clearTimeout(timer);
  }, [query]);
  const groupedResults = useMemo(() => {
    const assigned = new Set<number>();
    const groups = aiGroups.map((g, i) => {
      const items = g.entries.map(meta => results.find(a => a.malId === meta.malId)).filter((a): a is Anime => !!a);
      items.forEach(a => assigned.add(a.malId));
      return { key: 'ai-' + i + '-' + g.franchise, title: g.franchise || items[0]?.title || 'Anime', items, metadata: g.entries };
    }).filter(g => g.items.length);
    const fallback = new Map<string, Anime[]>();
    for (const a of results) if (!assigned.has(a.malId)) { const key = franchiseKey(a.title); fallback.set(key, [...(fallback.get(key) || []), a]); }
    for (const [key, items] of fallback) groups.push({ key, title: franchiseTitle(key, items.map(anime => ({ id: String(anime.malId), anime, watchedSeasons: [], watchedEpisodes: {}, addedAt: '' }))), items, metadata: [] });
    return groups;
  }, [results, aiGroups]);
  async function addFranchise(items: Anime[]) {
    const seeds = items.map(a => a.malId);
    setAdding(true);
    setErrorMsg('');
    setAddNote('Mapping the franchise from MyAnimeList relations…');
    let total = 0;
    let complete = false;
    try {
      // Large franchises are resolved in time-boxed passes; cached nodes make each pass faster.
      for (let i = 0; i < 4 && !complete; i++) {
        const r = await api.post('/api/franchise/add', { seeds });
        total += r.data.added?.length || 0;
        complete = !!r.data.complete;
        if (total) setAddNote('Added ' + total + ' entries…');
      }
      await reloadList();
      setQuery('');
      setResults([]);
      setAiGroups([]);
      if (!complete) setErrorMsg('Franchise was only partly mapped (catalog rate limit). Tap Add franchise again to finish.');
      else if (!total) setErrorMsg('This franchise is already in your watchlist.');
    } catch {
      await reloadList().catch(() => undefined);
      setErrorMsg('Could not add this franchise. Please retry.');
    } finally {
      setAdding(false);
      setAddNote('');
    }
  }
  async function saveEntry(entry: Entry) {
    setEntries(v => v.map(x => (x.id === entry.id ? entry : x)));
    try {
      await api.put('/api/watchlist/' + encodeURIComponent(entry.id), {
        watchedSeasons: entry.watchedSeasons,
        watchedEpisodes: entry.watchedEpisodes,
      });
    } catch {
      setErrorMsg('Progress may not have saved. Refresh and try again.');
    }
  }
  async function removeEntry(entry: Entry) {
    if (!confirm('Remove ' + entry.anime.title + ' from your watchlist?')) return;
    try {
      await api.delete('/api/watchlist/' + encodeURIComponent(entry.id));
      setEntries(v => v.filter(x => x.id !== entry.id));
    } catch {
      // Trust the server, not the error: if the record is gone it was removed.
      try {
        const list = await reloadList();
        if (list.some(x => x.id === entry.id)) setErrorMsg('Could not remove this anime.');
      } catch {
        setErrorMsg('Could not remove this anime.');
      }
    }
  }
  async function removeFranchise(title: string, items: Entry[]) {
    if (!confirm('Remove ' + title + ' and all ' + items.length + ' entries (progress included)?')) return;
    const ids = items.map(e => e.id);
    try {
      await api.post('/api/watchlist/remove', { ids });
    } catch {
      /* verified against the server below */
    }
    try {
      const list = await reloadList();
      if (list.some(x => ids.includes(x.id))) setErrorMsg('Some entries could not be removed. Please retry.');
    } catch {
      setErrorMsg('Could not confirm removal. Refresh the list.');
    }
  }
  async function signIn() {
    try {
      const r = await auth.signIn();
      setUser(r.user);
      const w = await api.get('/api/watchlist');
      setEntries(w.data.entries || []);
      setErrorMsg('');
    } catch (e: any) {
      setErrorMsg(
        e?.code === 'popup_blocked'
          ? 'Allow pop-ups to sign in.'
          : e?.code === 'popup_closed'
            ? 'Sign-in was cancelled.'
            : 'Sign-in did not complete.'
      );
    }
  }
  async function signOut() {
    await auth.signOut();
    setUser(null);
    setEntries([]);
  }
  const totalWatched = entries.reduce(
    (n, e) =>
      n +
      Object.values(e.watchedEpisodes || {}).reduce((x, a) => x + a.length, 0),
    0
  );
  if (loading)
    return (
      <main className="loading">
        <div className="brandmark">
          <Clapperboard />
        </div>
        <p>Loading your anime universe…</p>
      </main>
    );
  if (!user)
    return (
      <main className="login-shell">
        <div className="login-art">
          <div className="orbit orbit-one" />
          <div className="orbit orbit-two" />
          <div className="hero-kanji">アニメ</div>
          <div className="hero-copy">
            <span className="eyebrow">
              <Sparkles size={14} /> YOUR PERSONAL ANIME ARCHIVE
            </span>
            <h1>
              Every episode.
              <br />
              <em>Every memory.</em>
            </h1>
            <p>
              One clean place to track every season, every episode, and every
              series you’ve watched.
            </p>
          </div>
          <div className="poster-stack">
            <span>01 / DISCOVER</span>
            <span>02 / TRACK</span>
            <span>03 / COMPLETE</span>
          </div>
        </div>
        <section className="login-card">
          <div className="brand">
            <span className="brand-icon">
              <Clapperboard size={20} />
            </span>
            <span>
              ani<span className="accent">track</span>
            </span>
          </div>
          <div className="login-content">
            <div className="mini-label">WELCOME TO YOUR WATCHLIST</div>
            <h2>
              Your anime life,
              <br />
              beautifully organized.
            </h2>
            <p>
              Sign in to save your watch progress securely and pick up exactly
              where you left off.
            </p>
            <button className="primary full" onClick={signIn}>
              Continue to AniTrack <ChevronRight size={18} />
            </button>
            <div className="login-note">
              <span className="secure-dot" /> Secure account sign-in{' '}
              <span>·</span> Private watchlist
            </div>
            {errorMsg && <div className="error">{errorMsg}</div>}
            <div className="login-foot">
              Catalog data sourced from MyAnimeList through Jikan API.
            </div>
          </div>
        </section>
      </main>
    );
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <span className="brand-icon">
            <Clapperboard size={20} />
          </span>
          <span>
            ani<span className="accent">track</span>
          </span>
        </div>
        <div className="side-label">LIBRARY</div>
        <button
          className={'nav-item ' + (tab === 'all' ? 'active' : '')}
          onClick={() => setTab('all')}
        >
          <Clapperboard size={17} /> All anime <span>{entries.length}</span>
        </button>
        <button
          className={'nav-item ' + (tab === 'watching' ? 'active' : '')}
          onClick={() => setTab('watching')}
        >
          <Play size={17} /> In progress
        </button>
        <button
          className={'nav-item ' + (tab === 'completed' ? 'active' : '')}
          onClick={() => setTab('completed')}
        >
          <Check size={17} /> Completed
        </button>
        <div className="sidebar-bottom">
          <div className="sync-card">
            <div className="sync-icon">
              <RefreshCw size={16} />
            </div>
            <strong>Catalog sync</strong>
            <p>
              Metadata refreshes every 5 minutes while the app is open. Your watched progress is never changed.
            </p>
            <small>
              <span className="secure-dot" />{' '}
              {lastRefreshed ? 'Last refresh ' + new Date(lastRefreshed).toLocaleTimeString() : 'Waiting for first refresh'}
            </small>
            {refreshNote && <small className="refresh-note">{refreshNote}</small>}
          </div>
          <button className="account" onClick={signOut}>
            <div className="avatar">
              {(user.name || user.email || 'A').slice(0, 1).toUpperCase()}
            </div>
            <div className="account-name">
              <strong>{user.name || 'Anime fan'}</strong>
              <small>Signed in</small>
            </div>
            <LogOut size={16} />
          </button>
        </div>
      </aside>
      <main className="main">
        <header className="topbar">
          <div>
            <div className="mini-label">YOUR COLLECTION</div>
            <h1>
              Anime watchlist<span className="period">.</span>
            </h1>
          </div>
          <div className="top-actions">
            <span className="source-pill">
              <span className="secure-dot" /> MAL catalog
            </span>
            <button
              className="icon-btn"
              title="Refresh list"
              onClick={() =>
                refreshList().catch(() => setErrorMsg('Refresh failed.'))
              }
            >
              <RefreshCw size={17} />
            </button>
          </div>
        </header>
        <section className="stats">
          <div className="stat-card">
            <span>IN YOUR LIBRARY</span>
            <strong>{entries.length.toString().padStart(2, '0')}</strong>
            <small>series saved</small>
          </div>
          <div className="stat-card">
            <span>EPISODES WATCHED</span>
            <strong>{totalWatched.toString().padStart(2, '0')}</strong>
            <small>episodes checked off</small>
          </div>
          <div className="stat-card accent-card">
            <span>YOUR JOURNEY</span>
            <strong>
              {entries.filter(completed).length.toString().padStart(2, '0')}
              <small> / {entries.length.toString().padStart(2, '0')}</small>
            </strong>
            <small>series completed</small>
          </div>
        </section>
        <section className="search-panel">
          <div className="search-heading">
            <div>
              <span className="mini-label">FIND YOUR NEXT ENTRY</span>
              <h2>Add anime</h2>
            </div>
            <span className="source-note">
              <Sparkles size={14} /> {catalogInfo}
            </span>
          </div>
          <form className="searchbar" onSubmit={searchAnime}>
            <Search size={19} />
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Escape') { setResults([]); setAiGroups([]); setSelectedGroup(0); return; }
                if (e.key === 'ArrowDown' && groupedResults.length) { e.preventDefault(); setSelectedGroup(v => Math.min(v + 1, groupedResults.length - 1)); }
                if (e.key === 'ArrowUp' && groupedResults.length) { e.preventDefault(); setSelectedGroup(v => Math.max(0, v - 1)); }
                if (e.key === 'Enter' && groupedResults.length && !e.shiftKey) { e.preventDefault(); void addFranchise(groupedResults[Math.min(selectedGroup, groupedResults.length - 1)].items); }
              }}
              placeholder="Search any anime title…"
              aria-label="Search anime"
            />
            <button
              className="primary"
              type="submit"
              disabled={searching || !query.trim()}
            >
              {searching ? 'Searching…' : 'Search'} <ChevronRight size={16} />
            </button>
          </form>
          {addNote && <div className="suggestion-label">{addNote}</div>}
          {searching && <div className="suggestion-label">Searching the catalog…</div>}
          {!searching && query.trim().length >= 2 && groupedResults.length === 0 && <div className="suggestion-label">No matching anime found.</div>}
          {groupedResults.length > 0 && (
            <div className="search-results">
              <div className="suggestion-label">MATCHING ANIME · GROUPED BY FRANCHISE</div>
              {groupedResults.map((group, groupIndex) => (
                <div className={'franchise-search-group' + (groupIndex === selectedGroup ? ' selected' : '')} key={group.key} aria-selected={groupIndex === selectedGroup}>
                  <div className="franchise-search-heading">
                    <div><strong>{group.title}</strong><span>{group.items.length} matching entries · full franchise added automatically</span></div>
                    <button className="add-btn" disabled={adding || group.items.every(a => entries.some(x => x.anime.malId === a.malId && x.anime.franchiseId))} onClick={() => void addFranchise(group.items)}><Plus size={17} />{adding ? 'Adding…' : group.items.every(a => entries.some(x => x.anime.malId === a.malId && x.anime.franchiseId)) ? 'Added' : 'Add franchise'}</button>
                  </div>
                  {group.items.map(a => (
                <div className="result-row" key={a.malId}>
                  {a.image ? (
                    <img src={a.image} alt={a.title + ' cover'} loading="lazy" />
                  ) : (
                    <div className="poster-placeholder">
                      <Clapperboard />
                    </div>
                  )}
                  <div className="result-info">
                    <strong>{a.title}</strong>
                    <span>
                      {a.year || 'Year unknown'} · {a.episodes ?? '?'} eps ·{' '}
                      {a.status || 'Status unknown'}
                    </span>
                    <p>{a.synopsis || 'No synopsis available.'}</p>
                  </div>
                </div>
                  ))}
                </div>
              ))}
            </div>
          )}
          {errorMsg && (
            <div className="error">
              {errorMsg}
              <button onClick={() => setErrorMsg('')}>Dismiss</button>
            </div>
          )}
        </section>
        <section className="list-section">
          <div className="list-heading">
            <div>
              <span className="mini-label">YOUR PERSONAL ARCHIVE</span>
              <h2>
                {tab === 'all'
                  ? 'Saved series'
                  : tab === 'watching'
                    ? 'In progress'
                    : 'Completed series'}{' '}
                <span>{filtered.length}</span>
              </h2>
            </div>
            <div className="sort-label">
              <Clock3 size={15} /> Recently added
            </div>
          </div>
          {filtered.length === 0 ? (
            <div className="empty">
              <div className="empty-icon">
                <Clapperboard size={25} />
              </div>
              <h3>
                {entries.length === 0
                  ? 'Your story starts here'
                  : 'Nothing in this section yet'}
              </h3>
              <p>
                Search the catalog above and add an anime to start tracking
                seasons and episodes.
              </p>
            </div>
          ) : (
            <div className="anime-list">
              {groupedFiltered.map(group => (
                <div className="franchise-card" key={group.key}>
                  <div className="franchise-card-heading">
                    <h3>{group.title}</h3>
                    <span>
                      {group.entries.length} {group.entries.length === 1 ? 'entry' : 'entries'}
                      {group.known > 0 ? ' · ' + group.watched + ' / ' + group.known + ' eps' : ''}
                    </span>
                    <button className="trash-btn" title="Remove franchise" onClick={() => removeFranchise(group.title, group.entries)}>
                      <Trash2 size={16} />
                    </button>
                  </div>
                  {group.entries.map((entry, entryIndex) => {
                const seasons = seasonLabels(entry.anime);
                const watched = Object.values(
                  entry.watchedEpisodes || {}
                ).reduce((n, a) => n + a.length, 0);
                const pct = progress(entry);
                const prevKind = entryIndex > 0 ? group.entries[entryIndex - 1].anime.kind : undefined;
                const showHeading = entryIndex === 0 || prevKind !== entry.anime.kind;
                return (
                  <Fragment key={entry.id}>
                  {showHeading && <div className="kind-heading">{kindHeading[entry.anime.kind || 'special']}</div>}
                  <article className="anime-card">
                    <div className="anime-cover">
                      {entry.anime.image ? (
                        <img src={entry.anime.image} alt="" loading="lazy" />
                      ) : (
                        <div className="poster-placeholder">
                          <Clapperboard size={28} />
                        </div>
                      )}
                      <span className="cover-index">
                        MAL {entry.anime.malId}
                      </span>
                    </div>
                    <div className="anime-body">
                      <div className="anime-title-row">
                        <div>
                          <div className="anime-meta">
                            {kindBadge(entry.anime) && <><b className="kind-badge">{kindBadge(entry.anime)}</b> <span>•</span>{' '}</>}
                            {entry.anime.year || 'ANIME'} <span>•</span>{' '}
                            {entry.anime.status || 'STATUS UNKNOWN'}
                          </div>
                          <h3>{entry.anime.title}</h3>
                        </div>
                        <button
                          className="trash-btn"
                          title="Remove anime"
                          onClick={() => removeEntry(entry)}
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                      <div className="progress-line">
                        <div className="progress-track">
                          <div style={{ width: pct + '%' }} />
                        </div>
                        <span>{pct}%</span>
                      </div>
                      <div className="progress-caption">
                        {watched} episode{watched === 1 ? '' : 's'} individually
                        checked · {entry.watchedSeasons.length} full season
                        {entry.watchedSeasons.length === 1 ? '' : 's'} marked
                      </div>
                      <div className="season-list">
                        {Array.from({ length: seasons }, (_, i) => i + 1).map(
                          s => {
                            const key = String(s);
                            const isOpen = !!open[entry.id + '-' + key];
                            const isSeasonDone =
                              entry.watchedSeasons.includes(s);
                            const epCount = entry.anime.episodes;
                            const knownEpisodeCount = Number.isInteger(epCount) && (epCount as number) > 0;
                            const displayEpisodeCount = knownEpisodeCount ? epCount as number : 0;
                            const watchedEps =
                              entry.watchedEpisodes?.[key] || [];
                            return (
                              <div className="season" key={s}>
                                <div className="season-row">
                                  <button
                                    className="season-toggle"
                                    onClick={() =>
                                      setOpen(v => ({
                                        ...v,
                                        [entry.id + '-' + key]: !isOpen,
                                      }))
                                    }
                                  >
                                    {isOpen ? (
                                      <ChevronDown size={16} />
                                    ) : (
                                      <ChevronRight size={16} />
                                    )}
                                    <span>Episodes</span>
                                    <small>
                                      {!knownEpisodeCount ? 'Unknown episode count' : isSeasonDone ? 'Complete' : watchedEps.length + ' / ' + displayEpisodeCount + ' eps'}
                                    </small>
                                  </button>
                                  {knownEpisodeCount && <button
                                    className={
                                      'season-check ' +
                                      (isSeasonDone ? 'checked' : '')
                                    }
                                    onClick={() =>
                                      saveEntry({
                                        ...entry,
                                        watchedSeasons: isSeasonDone
                                          ? entry.watchedSeasons.filter(
                                              n => n !== s
                                            )
                                          : [...entry.watchedSeasons, s],
                                        watchedEpisodes: {
                                          ...entry.watchedEpisodes,
                                          [key]: isSeasonDone
                                            ? entry.watchedEpisodes[key] || []
                                            : Array.from(
                                                { length: displayEpisodeCount },
                                                (_, n) => n + 1
                                              ),
                                        },
                                      })
                                    }
                                  >
                                    {isSeasonDone ? (
                                      <Check size={15} />
                                    ) : (
                                      <span />
                                    )}
                                    {isSeasonDone ? 'Watched' : 'Mark all episodes'}
                                  </button>}
                                </div>
                                {isOpen && knownEpisodeCount && (
                                  <div className="episode-grid">
                                    {Array.from(
                                      { length: displayEpisodeCount },
                                      (_, i) => i + 1
                                    ).map(ep => {
                                      const checked =
                                        isSeasonDone || watchedEps.includes(ep);
                                      return (
                                        <button
                                          key={ep}
                                          className={
                                            'episode ' +
                                            (checked ? 'episode-done' : '')
                                          }
                                          onClick={() => {
                                            const old =
                                              entry.watchedEpisodes?.[key] ||
                                              [];
                                            const next = checked
                                              ? old.filter(n => n !== ep)
                                              : [...old, ep].sort(
                                                  (a, b) => a - b
                                                );
                                            const allDone =
                                              next.length === displayEpisodeCount;
                                            saveEntry({
                                              ...entry,
                                              watchedSeasons: allDone
                                                ? [
                                                    ...new Set([
                                                      ...entry.watchedSeasons,
                                                      s,
                                                    ]),
                                                  ]
                                                : entry.watchedSeasons.filter(
                                                    n => n !== s
                                                  ),
                                              watchedEpisodes: {
                                                ...entry.watchedEpisodes,
                                                [key]: next,
                                              },
                                            });
                                          }}
                                        >
                                          <span>
                                            {checked ? (
                                              <Check size={13} />
                                            ) : null}
                                          </span>{' '}
                                          EP {ep}
                                        </button>
                                      );
                                    })}
                                  </div>
                                )}
                              </div>
                            );
                          }
                        )}
                      </div>
                    </div>
                  </article>
                  </Fragment>
                );
                  })}
                </div>
              ))}
            </div>
          )}
        </section>
        <footer>
          Made for the love of anime <span>✦</span> Metadata by MyAnimeList /
          Jikan
        </footer>
      </main>
    </div>
  );
}
export default App;
